//
//  ViewController.swift
//  reset10
//
//  Created by Kevin Pradjinata on 6/20/20.
//  Copyright © 2020 Kevin Pradjinata. All rights reserved.
//

import UIKit
import Vision
import VisionKit
import AWSS3


class ViewController: UIViewController {
    @IBOutlet weak var myView: UIImageView!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var scanButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    let picker = UIImagePickerController()
    let transferUtility = AWSS3TransferUtility.default()
    let S3BucketName = "breaddyandbuttery1"
    
    private var ocrRequest = VNRecognizeTextRequest(completionHandler: nil)
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        /*
        let identityID = "us-east-1:1de81eef-f944-4df5-b79a-bff9c66eb1b4"

            
            let credentialsProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: identityID)
            
            let configuration = AWSServiceConfiguration(region: .USEast1, credentialsProvider: credentialsProvider)
            
            AWSServiceManager.default()?.defaultServiceConfiguration = configuration
   */
        
        configureOCR()
        // Do any additional setup after loading the view.
    }

 /*   override func viewWillAppear(_: Bool) {
        super.viewWillAppear(true)
    }
*/
    @objc private func scanDocument() {
        let scanVC = VNDocumentCameraViewController()
        scanVC.delegate = self
        present(scanVC, animated: true)
    }
    
    private func processImage(_ image: UIImage) {
        guard let cgImage = image.cgImage else { return }

        textView.text = ""
        scanButton.isEnabled = false
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        do {
            try requestHandler.perform([self.ocrRequest])
        } catch {
            print(error)
        }
    }
    
    private func configureOCR() {
        ocrRequest = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            
            var ocrText = ""
            for observation in observations {
                guard let topCandidate =
                    observation.topCandidates(1).first else { return }
                print(topCandidate)
                ocrText += topCandidate.string + "\n"
            }
            
            
            DispatchQueue.main.async {
                self.textView.text = ocrText
                self.scanButton.isEnabled = true
            }
        }
        
        ocrRequest.recognitionLevel = .accurate
        ocrRequest.recognitionLanguages = ["en-US", "en-GB"]
        ocrRequest.usesLanguageCorrection = true
    }
    
    @IBAction func scanButton(_ sender: Any) {
         scanButton.addTarget(self, action: #selector(scanDocument), for: .touchUpInside)
             }
    
    @IBAction func saveButton(_ sender: Any) {
        guard let image = myView.image else {return}
        //let compressedImage = image.resizedImage(newSize: CGSize(width: 100, height: 100))
                let pngImage = image.pngData()
                 let filename = "orderimage.png"
                
                                    
                    let upload = AWSS3TransferUtilityUploadExpression()
                    upload.progressBlock = { (task, progress) in
                        DispatchQueue.main.async(execute: {
                            print("Progress \(progress.fractionCompleted * 100) %")
                        })
                    }
                    var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
                    completionHandler = { (task, error) -> Void in
                        DispatchQueue.main.async(execute: {
                            print("Completed!")
                        })
                    }
                    let data: Data = pngImage!
                    transferUtility.uploadData(data, bucket: S3BucketName, key: filename,contentType: "image/png", expression:upload, completionHandler: completionHandler).continueWith(block: { (task) -> Any? in
                         if let error = task.error{
                             print("Error unable to load \(error)")
                         }
                        print("Upload completed")
                        return nil
                     })
               
        let download = AWSS3TransferUtilityDownloadExpression()
        download.progressBlock = {(task, progress) in DispatchQueue.main.async(execute: {
            print("Downloading \(progress.fractionCompleted * 100) %")
        })
        }
        
        transferUtility.downloadData(fromBucket: S3BucketName, key: filename, expression: download) { (task, URL, data, error) in
                if error != nil {
                    print(error!)
                    return
                }
                DispatchQueue.main.async(execute: {
                    print("Download completed")
                })
        }
    }
}
    

extension ViewController: VNDocumentCameraViewControllerDelegate {
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        guard scan.pageCount >= 1 else {
            controller.dismiss(animated: true)
            return
        }
        
        myView.image = scan.imageOfPage(at: 0)
        processImage(scan.imageOfPage(at: 0))
        controller.dismiss(animated: true)
    }
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
        //Handle properly error
        controller.dismiss(animated: true)
    }
    
    func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
        controller.dismiss(animated: true)
    }
}

